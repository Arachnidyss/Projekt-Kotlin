package com.miu.meditationapp.models

class PostHistory(val uid:String, val posteddate:String, val postbody: String)